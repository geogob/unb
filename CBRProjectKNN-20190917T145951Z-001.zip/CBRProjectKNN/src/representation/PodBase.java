package representation;

import jcolibri.cbrcore.Attribute;
import jcolibri.cbrcore.CaseComponent;


public class PodBase implements CaseComponent { 


	/* Generated Class. Please Do Not Modify... */ 

	private java.lang.Integer label;


	public java.lang.Integer getLabel()
		{
			return label;
		}
	public void setLabel(java.lang.Integer label0)
		{
			this.label = label0;
		}

	private java.lang.Integer dissimilality;


	public java.lang.Integer getDissimilality()
		{
			return dissimilality;
		}
	public void setDissimilality(java.lang.Integer dissimilality1)
		{
			this.dissimilality = dissimilality1;
		}

	private java.lang.Integer asm;


	public java.lang.Integer getAsm()
		{
			return asm;
		}
	public void setAsm(java.lang.Integer asm2)
		{
			this.asm = asm2;
		}

	private java.lang.Integer energy;


	public java.lang.Integer getEnergy()
		{
			return energy;
		}
	public void setEnergy(java.lang.Integer energy3)
		{
			this.energy = energy3;
		}

	private java.lang.Integer correlation;


	public java.lang.Integer getCorrelation()
		{
			return correlation;
		}
	public void setCorrelation(java.lang.Integer correlation4)
		{
			this.correlation = correlation4;
		}

	private java.lang.Integer idDescription;


	public java.lang.Integer getIdDescription()
		{
			return idDescription;
		}
	public void setIdDescription(java.lang.Integer idDescription5)
		{
			this.idDescription = idDescription5;
		}

	private java.lang.Integer homogeneity;


	public java.lang.Integer getHomogeneity()
		{
			return homogeneity;
		}
	public void setHomogeneity(java.lang.Integer homogeneity6)
		{
			this.homogeneity = homogeneity6;
		}

	private java.lang.Integer contrast;


	public java.lang.Integer getContrast()
		{
			return contrast;
		}
	public void setContrast(java.lang.Integer contrast7)
		{
			this.contrast = contrast7;
		}


	@Override
	public Attribute getIdAttribute()
		{
			return new Attribute("idDescription",this.getClass());
		} 

	public String toString()		{
			return "["+ idDescription + " , " + correlation + " , " + contrast + " , " + asm + " , " + label + " , " + dissimilality + " , " + energy + " , " + homogeneity +"]";
		}

}
