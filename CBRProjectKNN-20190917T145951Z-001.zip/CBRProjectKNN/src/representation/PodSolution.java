package representation;

import jcolibri.cbrcore.Attribute;
import jcolibri.cbrcore.CaseComponent;


public class PodSolution implements CaseComponent { 


	/* Generated Class. Please Do Not Modify... */ 

	private java.lang.Integer idSolution;


	public java.lang.Integer getIdSolution()
		{
			return idSolution;
		}
	public void setIdSolution(java.lang.Integer idSolution8)
		{
			this.idSolution = idSolution8;
		}


	@Override
	public Attribute getIdAttribute()
		{
			return new Attribute("idSolution",this.getClass());
		} 

	public String toString()		{
			return "["+ idSolution +"]";
		}

}
